# Materiais em Lote

Relatórios de um cenário declarado, sem reserva de estoque ou compra real.

projeto.json é a entrada original; plano.json é a memória estruturada. CSV e Markdown resumem o plano. XLSX tem quatro abas e quantidades como texto exato: é estático e não recalcula ao editar células. Não converter n/d para float se precisar de igualdade exata.

CSV acrescenta apóstrofo a textos que começam com =, +, - ou @ (após espaços). O JSON e o XLSX preservam esses textos literalmente. Os IDs e as quantidades têm gramáticas próprias.

manifesto.json identifica seis membros por tamanho e SHA-256; hashes não autenticam o autor. Quantidades de unidades diferentes não têm um total geral. Guarde a entrada para recalcular.

LOFRANO TECNOLOGIA - https://lofranotecnologia.com.br/
