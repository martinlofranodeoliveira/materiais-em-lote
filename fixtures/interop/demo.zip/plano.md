# Uma oficina, dois pedidos

Plano declarado de materiais. Estoque e pedidos vêm da entrada; não houve reserva ou compra.

Cada quantidade usa a unidade do próprio item. Frações são exatas; não somar unidades diferentes.

| Item | Unidade | Tipo | Bruta | Estoque | Usado | Líquida | Lote | Lotes | Planejado | Saldo |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| expositor \- Expositor de bancada | un | Fabricar | 2 | 0 | 0 | 2 | 1 | 2 | 2 | 0 |
| kit \- Kit de oficina | un | Fabricar | 3 | 1 | 1 | 2 | 2 | 1 | 2 | 0 |
| painel \- Painel preparado | un | Fabricar | 7 | 2 | 2 | 5 | 3 | 2 | 6 | 1 |
| chapa \- Chapa | un | Comprar | 2 | 1 | 1 | 1 | 2 | 1 | 2 | 1 |
| suporte \- Suporte | un | Comprar | 8 | 1 | 1 | 7 | 4 | 2 | 8 | 1 |
| tinta \- Tinta | l | Comprar | 1\.5 | 0\.3 | 0\.3 | 1\.2 | 1 | 2 | 2 | 0\.8 |

## Origens da demanda

| Item | Origem | Quantidade |
| --- | --- | --- |
| expositor | Pedido pedido\-expositor | 2 |
| kit | Pedido pedido\-kit | 3 |
| painel | Produção de expositor | 4 |
| painel | Produção de kit | 3 |
| chapa | Produção de painel | 2 |
| suporte | Produção de expositor | 4 |
| suporte | Produção de kit | 4 |
| tinta | Produção de expositor | 0\.4 |
| tinta | Produção de kit | 0\.5 |
| tinta | Produção de painel | 0\.6 |

## Como ler

A demanda de todos os pais é reunida antes de descontar o estoque uma única vez. Fabricados geram componentes somente pelos lotes necessários. Comprados são arredondados por embalagem. Saldo final = estoque inicial + quantidade planejada - demanda bruta.

O relatório XLSX é estático. Edite a entrada JSON e gere outro pacote para recalcular. Não há conversão de unidades, custos, prazos ou otimização de produção.

LOFRANO TECNOLOGIA - https://lofranotecnologia.com.br/
