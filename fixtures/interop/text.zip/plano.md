# =Oficina &lt;A&amp;B&gt; – ação

Plano declarado de materiais. Estoque e pedidos vêm da entrada; não houve reserva ou compra.

Cada quantidade usa a unidade do próprio item. Frações são exatas; não somar unidades diferentes.

| Item | Unidade | Tipo | Bruta | Estoque | Usado | Líquida | Lote | Lotes | Planejado | Saldo |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| arroba \- @SUM\(A1:A2\) | un | Comprar | 1 | 0 | 0 | 1 | 1 | 1 | 1 | 0 |
| escape\-adjacente \- \_x0041\_\_x000D\_ | un | Comprar | 1 | 0 | 0 | 1 | 1 | 1 | 1 | 0 |
| escape\-cr \- \_x000D\_ | un | Comprar | 1 | 0 | 0 | 1 | 1 | 1 | 1 | 0 |
| escape\-protegido \- \_x005F\_x0041\_ | un | Comprar | 1 | 0 | 0 | 1 | 1 | 1 | 1 | 0 |
| escape\-sobreposto \- \_x0041\_x000D\_ | un | Comprar | 1 | 0 | 0 | 1 | 1 | 1 | 1 | 0 |
| escape\-utf16 \- \_xD83D\_\_xDE00\_ | un | Comprar | 1 | 0 | 0 | 1 | 1 | 1 | 1 | 0 |
| item\_x0041\_ \- \_x0041\_ | un | Comprar | 1 | 0 | 0 | 1 | 1 | 1 | 1 | 0 |
| mais \- \+SUM\(A1:A2\) | un | Comprar | 0\.1 | 0 | 0 | 0\.1 | 2 | 1 | 2 | 1\.9 |
| menos \- \-2\+3 | un | Comprar | 1 | 0 | 0 | 1 | 1 | 1 | 1 | 0 |
| xml \- Aço &lt;&amp;&gt; "ação" 'ç' | un | Fabricar | 1 | 0 | 0 | 1 | 3 | 1 | 3 | 2 |
| igual \- =1\+1 | un | Comprar | 1 | 0 | 0 | 1 | 1 | 1 | 1 | 0 |

## Origens da demanda

| Item | Origem | Quantidade |
| --- | --- | --- |
| arroba | Pedido pedido\-arroba | 1 |
| escape\-adjacente | Pedido pedido\-escape\-adjacente | 1 |
| escape\-cr | Pedido pedido\-escape\-cr | 1 |
| escape\-protegido | Pedido pedido\-escape\-protegido | 1 |
| escape\-sobreposto | Pedido pedido\-escape\-sobreposto | 1 |
| escape\-utf16 | Pedido pedido\-escape\-utf16 | 1 |
| item\_x0041\_ | Pedido pedido\-item\_x0041\_ | 1 |
| mais | Pedido pedido\-mais | 0\.1 |
| menos | Pedido pedido\-menos | 1 |
| xml | Pedido pedido\-xml | 1 |
| igual | Produção de xml | 1 |

## Como ler

A demanda de todos os pais é reunida antes de descontar o estoque uma única vez. Fabricados geram componentes somente pelos lotes necessários. Comprados são arredondados por embalagem. Saldo final = estoque inicial + quantidade planejada - demanda bruta.

O relatório XLSX é estático. Edite a entrada JSON e gere outro pacote para recalcular. Não há conversão de unidades, custos, prazos ou otimização de produção.

LOFRANO TECNOLOGIA - https://lofranotecnologia.com.br/
